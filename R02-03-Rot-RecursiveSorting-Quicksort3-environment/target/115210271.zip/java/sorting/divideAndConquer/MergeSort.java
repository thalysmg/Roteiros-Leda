package sorting.divideAndConquer;

import sorting.AbstractSorting;

/**
 * Merge sort is based on the divide-and-conquer paradigm. The algorithm
 * consists of recursively dividing the unsorted list in the middle, sorting
 * each sublist, and then merging them into one single sorted list. Notice that
 * if the list has length == 1, it is already sorted.
 */
public class MergeSort<T extends Comparable<T>> extends AbstractSorting<T> {

   @Override
   public void sort(T[] array, int leftIndex, int rightIndex) {
      mergeSort(array, (T[]) new Comparable[array.length], leftIndex, rightIndex);
   }

   public void mergeSort(T[] array, T[] temp, int leftIndex, int rightIndex) {

      if (leftIndex >= rightIndex) {
         return;
      }
      int middle = (leftIndex + rightIndex) / 2;
      sort(array, leftIndex, middle);
      sort(array, middle + 1, rightIndex);
      merge(array, temp, leftIndex, rightIndex);
   }

   private void merge(T[] array, T[] temp, int leftIndex, int rightIndex) {
      int leftEnd = (rightIndex + leftIndex) / 2;
      int rightStart = leftEnd + 1;
      int size = rightIndex - leftIndex + 1;

      int left = leftIndex;
      int right = rightStart;
      int index = leftIndex;

      while (left <= leftEnd && right <= rightIndex) {
         if (array[left].compareTo(array[right]) <= 0) {
            temp[index] = array[left];
            left++;
         } else {
            temp[index] = array[right];
            right++;
         }
         index++;
      }
      System.arraycopy(array, left, temp, index, leftEnd - left + 1);
      System.arraycopy(array, right, temp, index, rightIndex - right + 1);
      System.arraycopy(temp, leftIndex, array, leftIndex, size);
   }

}
