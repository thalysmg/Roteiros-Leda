package adt.linkedList;

public class DoubleLinkedListImpl<T> extends SingleLinkedListImpl<T> implements DoubleLinkedList<T> {

	protected DoubleLinkedListNode<T> last;

	@Override
	public void insertFirst(T element) {
		if (element == null)
			return;

		SingleLinkedListNode<T> aux = getHead();
		DoubleLinkedListNode<T> newNode = new DoubleLinkedListNode<>();
		newNode.setData(element);

		if (!isEmpty()) {
			((DoubleLinkedListNode<T>) aux).getPrevious().setNext(newNode);
			newNode.setNext(aux);
			newNode.setPrevious(((DoubleLinkedListNode<T>) aux).getPrevious());
			((DoubleLinkedListNode<T>) aux).setPrevious(newNode);

			setHead(newNode);

		} else {
			DoubleLinkedListNode<T> rightNil = new DoubleLinkedListNode<>();
			DoubleLinkedListNode<T> leftNil = new DoubleLinkedListNode<>();

			newNode.setPrevious(leftNil);
			leftNil.setNext(newNode);

			rightNil.setPrevious(newNode);
			newNode.setNext(rightNil);

			setHead(newNode);
			setLast(newNode);

		}
	}

	@Override
	public void insert(T element) {
		if (element == null) {
			return;
		}

		DoubleLinkedListNode<T> newNode = new DoubleLinkedListNode<>();
		newNode.setData(element);

		if (!isEmpty()) {
			newNode.setNext(getLast().getNext());
			getLast().setNext(newNode);

			newNode.setPrevious(getLast());

			DoubleLinkedListNode<T> nillDireita = (DoubleLinkedListNode<T>) newNode.getNext();
			nillDireita.setPrevious(newNode);

			setLast(newNode);

		} else {
			DoubleLinkedListNode<T> nilDireita = new DoubleLinkedListNode<>();
			DoubleLinkedListNode<T> nilEsquera = new DoubleLinkedListNode<>();

			newNode.setPrevious(nilEsquera);
			nilEsquera.setNext(newNode);

			nilDireita.setPrevious(newNode);
			newNode.setNext(nilDireita);

			setHead(newNode);
			setLast(newNode);
		}
	}
	
	@Override
	public void remove(T element) {
		if (element == null) {
			return;
		}

		if (isEmpty()) {
			return;
		}

		DoubleLinkedListNode<T> aux = (DoubleLinkedListNode<T>) getHead();

		while (!aux.isNIL() && !aux.getData().equals(element)) {
			aux = (DoubleLinkedListNode<T>) aux.getNext();
		}

		if (!aux.isNIL()) {
			aux.getPrevious().setNext(aux.getNext());

			DoubleLinkedListNode<T> nextAux = (DoubleLinkedListNode<T>) aux.getNext();
			nextAux.setPrevious(aux.getPrevious());

			if (aux.getNext().isNIL()) {
				setLast(getLast().getPrevious());
			}
		}
	}

	@Override
	public int size() {
		int size = 0;
		DoubleLinkedListNode<T> auxNode = (DoubleLinkedListNode<T>) super.head;
		while (!auxNode.isNIL()) {
			size++;
			auxNode = (DoubleLinkedListNode<T>) auxNode.getNext();
		}
		return size;
	}

	@Override
	public void removeFirst() {
		if (!isEmpty()) {
			DoubleLinkedListNode<T> aux = (DoubleLinkedListNode<T>) getHead();
			DoubleLinkedListNode<T> auxNext = (DoubleLinkedListNode<T>) aux.getNext();

			aux.getPrevious().setNext(auxNext);
			auxNext.setPrevious(aux.getPrevious());

			setHead(auxNext);
		}
	}

	@Override
	public void removeLast() {
		getLast().getPrevious().setNext(getLast().getNext());

		DoubleLinkedListNode<T> nilDireita = (DoubleLinkedListNode<T>) getLast().getNext();
		nilDireita.setPrevious(getLast().getPrevious());

		if (getLast().getPrevious().isNIL()) {
			setHead(getLast().getPrevious());
		}

		setLast(getLast().getPrevious());
	}

	public DoubleLinkedListNode<T> getLast() {
		return last;
	}

	public void setLast(DoubleLinkedListNode<T> last) {
		this.last = last;
	}
	@Override
	public DoubleLinkedListNode<T> getHead() {
		return (DoubleLinkedListNode<T>) super.head;
	}
	
}
